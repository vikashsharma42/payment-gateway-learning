using DineBook.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DineBook.Infrastructure.Database.Configurations
{
    /// <summary>
    /// Column mappings for value objects, shared by every configuration that owns one.
    /// </summary>
    public static class ValueObjectMappings
    {
        public static void MapAddress<TOwner>(OwnedNavigationBuilder<TOwner, Address> builder)
            where TOwner : class
        {
            builder.Property(a => a.Street).HasColumnName("Street").HasMaxLength(Address.MaxStreetLength).IsRequired();
            builder.Property(a => a.City).HasColumnName("City").HasMaxLength(Address.MaxCityLength).IsRequired();
            builder.Property(a => a.State).HasColumnName("State").HasMaxLength(Address.MaxStateLength).IsRequired();
            builder.Property(a => a.Country).HasColumnName("Country").HasMaxLength(Address.MaxCountryLength).IsRequired();
            builder.Property(a => a.ZipCode).HasColumnName("ZipCode").HasMaxLength(Address.MaxZipCodeLength).IsRequired();
        }

        public static void MapMoney<TOwner>(OwnedNavigationBuilder<TOwner, Money> builder)
            where TOwner : class
        {
            builder.Property(m => m.Amount).HasPrecision(18, 2);
            builder.Property(m => m.Currency).HasMaxLength(3).IsRequired();
        }
    }
}
