using DineBook.Domain.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using DineBook.Domain.Abstractions;
using DineBook.Domain.Entities.Dining;
using DineBook.Domain.Entities.Ordering;
using DineBook.Domain.Entities.Organization;
using DineBook.Domain.Enums;
using DineBook.Domain.Exceptions;

namespace DineBook.Domain.Entities.Payments
{
    /// <summary>
    /// What a reservation owes for the food ordered during it. The amount is fixed when the bill is created,
    /// so later changes to orders or menu prices do not change a bill that is already being paid.
    /// </summary>
    public class Bill : AggregateRoot, IAuditableEntity
    {
        // Required by EF Core: the orders passed to the public constructor are not stored on the bill
        private Bill()
        {
        }

        /// <summary>
        /// Totals every order that was not cancelled. A bill needs something to pay for.
        /// </summary>
        public Bill(long reservationId, long restaurantId, IEnumerable<Orders> orders)
        {
            DomainValidation<long>.Ensure(reservationId, "Reservation").IsGreaterThan(0, "Reservation is required.");
            DomainValidation<long>.Ensure(restaurantId, "Restaurant").IsGreaterThan(0, "Restaurant is required.");

            var amount = (orders ?? Enumerable.Empty<Orders>())
                .Where(o => o.Status != OrderStatus.Cancelled)
                .Sum(o => o.Total());

            DomainValidation<decimal>.Ensure(amount, "Amount")
                .IsGreaterThan(0, "There is nothing to pay yet. Order some food first.");

            ReservationId = reservationId;
            RestaurantId = restaurantId;
            Amount = amount;
            Status = PaymentStatus.Pending;
        }

        public long ReservationId { get; private set; }

        public long RestaurantId { get; private set; }

        public decimal Amount { get; private set; }

        // Pending until a payment succeeds. Failed attempts do not fail the bill: the guest can try again.
        public PaymentStatus Status { get; private set; }

        public DateTimeOffset CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTimeOffset UpdatedDateTime { get; set; }

        public string UpdatedBy { get; set; }

        // Bills are financial records: never removed with a reservation or restaurant
        [ForeignKey(nameof(ReservationId))]
        public virtual Reservation Reservation { get; private set; }

        [ForeignKey(nameof(RestaurantId))]
        public virtual Restaurant Restaurant { get; private set; }

        // Returns true only when the status actually changed, so duplicate webhooks change nothing.
        public bool MarkAsPaid()
        {
            if (Status == PaymentStatus.Paid)
                return false;

            DomainValidation<PaymentStatus>.Ensure(Status)
                .IsEqualTo(PaymentStatus.Pending, "Only pending bills can be marked as paid.");

            Status = PaymentStatus.Paid;
            return true;
        }

        public bool MarkAsRefunded()
        {
            if (Status == PaymentStatus.Refunded)
                return false;

            DomainValidation<PaymentStatus>.Ensure(Status)
                .IsEqualTo(PaymentStatus.Paid, "Only paid bills can be marked as refunded.");

            Status = PaymentStatus.Refunded;
            return true;
        }
    }
}
