using DineBook.Domain.Validation;
using System.ComponentModel.DataAnnotations.Schema;
using DineBook.Domain.Abstractions;
using DineBook.Domain.Enums;
using DineBook.Domain.Exceptions;
using System;

namespace DineBook.Domain.Entities.Payments
{
    /// <summary>
    /// One gateway payment attempt for a bill. The gateway order id ties it to Cashfree.
    /// </summary>
    public class Payment : Entity, IAuditableEntity
    {
        public Payment(
            long billId,
            decimal amount,
            string gatewayOrderId,
            string paymentSessionId,
            string idempotencyKey,
            string customerEmail)
        {
            DomainValidation<long>.Ensure(billId).IsGreaterThan(0, "Bill id is required.");
            DomainValidation<decimal>.Ensure(amount).IsGreaterThan(0, "Amount must be greater than zero.");
            DomainValidation<string>.Ensure(gatewayOrderId).IsNotNullOrWhiteSpace("Gateway order id is required.");
            DomainValidation<string>.Ensure(paymentSessionId).IsNotNullOrWhiteSpace("Payment session id is required.");
            DomainValidation<string>.Ensure(idempotencyKey).IsNotNullOrWhiteSpace("Idempotency key is required.");
            DomainValidation<string>.Ensure(customerEmail).IsNotNullOrWhiteSpace("Customer email is required.");

            BillId = billId;
            PublicId = Guid.NewGuid();
            Amount = amount;
            GatewayOrderId = gatewayOrderId.Trim();
            PaymentSessionId = paymentSessionId.Trim();
            IdempotencyKey = idempotencyKey.Trim();
            CustomerEmail = customerEmail.Trim();
            Status = PaymentStatus.Pending;
        }

        public long BillId { get; private set; }

        [ForeignKey(nameof(BillId))]
        public virtual Bill Bill { get; private set; }

        public Guid PublicId { get; private set; }

        public decimal Amount { get; private set; }

        public string GatewayOrderId { get; private set; }

        public string PaymentSessionId { get; private set; }

        public string IdempotencyKey { get; private set; }

        public string CustomerEmail { get; private set; }

        // Cashfree refund id. Set when a refund is requested, so a retry reuses it.
        public string RefundId { get; private set; }

        public PaymentStatus Status { get; private set; }

        public DateTimeOffset CreatedDateTime { get; set; }

        public string CreatedBy { get; set; }

        public DateTimeOffset UpdatedDateTime { get; set; }

        public string UpdatedBy { get; set; }

        // Returns true only when the status actually changed.
        // Duplicate webhooks or repeated status checks return false and change nothing.
        public bool MarkAsPaid()
        {
            if (Status == PaymentStatus.Paid)
                return false;

            DomainValidation<PaymentStatus>.Ensure(Status).IsEqualTo(PaymentStatus.Pending, "Only pending orders can be marked as paid.");

            Status = PaymentStatus.Paid;
            return true;
        }

        public void MarkAsFailed()
        {
            DomainValidation<PaymentStatus>.Ensure(Status)
                .IsNotEqualTo(PaymentStatus.Paid, "A paid payment cannot fail.");

            Status = PaymentStatus.Failed;
        }

        // Records the refund id before calling the gateway. Only paid payments can be refunded.
        public void RecordRefundRequest(string refundId)
        {
            DomainValidation<string>.Ensure(refundId, "Refund id").IsNotNullOrWhiteSpace();
            DomainValidation<PaymentStatus>.Ensure(Status)
                .IsEqualTo(PaymentStatus.Paid, "Only paid payments can be refunded.");
            DomainValidation<bool>.Ensure(RefundId is null || RefundId == refundId)
                .IsTrue("This payment already has a different refund in progress.");

            RefundId = refundId;
        }

        // Called only after the gateway confirms the refund succeeded.
        public bool MarkAsRefunded()
        {
            if (Status == PaymentStatus.Refunded)
                return false;

            DomainValidation<PaymentStatus>.Ensure(Status)
                .IsEqualTo(PaymentStatus.Paid, "Only paid payments can be marked as refunded.");

            Status = PaymentStatus.Refunded;
            return true;
        }

        // Used when Cashfree cancels a refund attempt, so a new request can start with a new id.
        public void ClearRefundRequest()
        {
            if (Status == PaymentStatus.Paid)
                RefundId = null;
        }
    }
}